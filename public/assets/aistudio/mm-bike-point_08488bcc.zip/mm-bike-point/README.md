# M.M. Bike Point website

Single-page showroom website (plain HTML, CSS and JavaScript, no build step).

- Open `index.html` in a browser to preview.
- Phone / WhatsApp: 9920818074
- Address: Shop No. 5 & 6, Mandapeshwar, Dahisar West, Mumbai 400103

## Host on GitHub Pages
Settings > Pages > Branch: main, folder: / (root) > Save.
